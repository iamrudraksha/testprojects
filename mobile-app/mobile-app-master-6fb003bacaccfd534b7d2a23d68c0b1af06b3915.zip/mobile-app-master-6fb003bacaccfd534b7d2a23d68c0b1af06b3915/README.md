Constant are declared as service in app.js "constantService"

If always need to show intro page when refresh uncomment line 13 in controller.js

deployment,

    if use ionic, move to extracted folder and just run "ionic serve"

    if use web server, copy www folder into root directory and open index.html


loading bar disappear soon because fast data loading.

I couldn't find way to link history page. Please use "#/app/history" check this page.